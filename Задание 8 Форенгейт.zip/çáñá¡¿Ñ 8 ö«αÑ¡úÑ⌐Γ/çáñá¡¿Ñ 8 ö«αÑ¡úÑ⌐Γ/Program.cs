﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание_8_Форенгейт
{
    class Program
    {
        static void Main(string[] args)
        {
            Double Forengeit;
            Console.Title = ("Калькулятор");
            Console.WriteLine("Введите цельсии");
            Forengeit = Convert.ToDouble(Console.ReadLine());
            Console.Write("По форенгейту = ");
            Console.Write(Forengeit * 9 / 5 + 32);
            Console.ReadKey();
        }
    }
}
