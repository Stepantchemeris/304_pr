﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание_10_треугольники
{
    class Program
    {
        static void Main(string[] args)
        {
            double A, B, C;

            Console.WriteLine("Введите первую сторону");
            A = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите вторую сторону");
            B = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите вторую сторону");
            C = Convert.ToInt32(Console.ReadLine());
            if (A + B <= C || A + C <= B || B + C <= A)
                Console.WriteLine("Такого треугольникА не существует");
            else if (A == B && B == C)
                Console.WriteLine("Это равносторонний треугольник");
            else if (A == B || A == C || B == C)
                Console.WriteLine("Это равнобедренный треугольник");
            else
                Console.WriteLine("Такой треугольник существует");
            Console.ReadKey();
        }
    }
}
