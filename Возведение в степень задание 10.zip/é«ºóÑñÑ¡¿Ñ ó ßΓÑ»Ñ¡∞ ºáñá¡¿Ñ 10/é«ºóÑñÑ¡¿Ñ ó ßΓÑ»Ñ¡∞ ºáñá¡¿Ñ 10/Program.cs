﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Возведение_в_степень_задание_10
{
    class Program
    {
        static void Main(string[] args)
        {
            Double a;
            Console.WriteLine("Введите число");
            a = Convert.ToDouble(Console.ReadLine());
            Console.Write("В квадрате = ");
            Console.WriteLine(Math.Pow(a, 2));
            Console.Write("В кубе = ");
            Console.WriteLine(Math.Pow(a, 3));
            Console.Write("В 4 степени = ");
            Console.WriteLine(Math.Pow(a, 4));
            Console.Write("В 5 степени = ");
            Console.WriteLine(Math.Pow(a, 5));
            Console.Write("В 6 степени = ");
            Console.WriteLine(Math.Pow(a, 6));
            Console.Write("В 7 степени = ");
            Console.WriteLine(Math.Pow(a, 7));
            Console.Write("В 8 степени = ");
            Console.WriteLine(Math.Pow(a, 8));
            Console.Write("В 9 степени = ");
            Console.WriteLine(Math.Pow(a, 9));
            Console.Write("В 10 степени = ");
            Console.WriteLine(Math.Pow(a, 10));

            Console.ReadKey();
        }
    }
}
