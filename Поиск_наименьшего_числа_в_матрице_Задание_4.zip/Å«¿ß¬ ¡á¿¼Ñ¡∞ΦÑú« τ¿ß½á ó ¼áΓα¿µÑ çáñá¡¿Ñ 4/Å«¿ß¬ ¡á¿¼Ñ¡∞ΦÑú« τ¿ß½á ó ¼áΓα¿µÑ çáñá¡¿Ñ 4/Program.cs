﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Поиск_наименьшего_числа_в_матрице_Задание_4
{
    class Program
    {
        static void Main(string[] args)
        {
            Random rnd = new Random();

            int[] Massiv = new int[rnd.Next(1, 100 + 1)];
            for (int i = 0; i < Massiv.Length; i++)
            {
                Massiv[i] = rnd.Next(1, 100 + 1);
            }
            Sort(Massiv);
            Console.WriteLine("Введите кол-во числе в массиве");
            int Massivmass = Convert.ToInt32(Console.ReadLine());
            int Massivmass1 = Massiv .Length - Massivmass;

            for (int i = 0; i < Massivmass; i++)
            {
                Console.Write(Massiv[i] + " ");
            }


            Console.ReadKey();
        }
        static void Sort(int[] Array)
        {
            for (int i = 0; i < Array.Length; i++)
            {
                for (int j = 0; j < Array.Length - 1; j++)
                {
                    if (Array[j] > Array[j + 1])
                    {
                        int temp = Array[j];
                        Array[j] = Array[j + 1];
                        Array[j + 1] = temp;
                    }
                }
            }
        }
    }
}