﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Равность_чисел_задание_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Double n1, n2, n3, n4;
            Console.WriteLine("Введите числа");
            n1 = Convert.ToDouble(Console.ReadLine());
            n2 = Convert.ToDouble(Console.ReadLine());
            n3 = Convert.ToDouble(Console.ReadLine());
            n4 = Convert.ToDouble(Console.ReadLine());
            if (n2 == n1 && n1 == n3 && n3 == n4)
            {
                Console.WriteLine("Числа равны");
            }
            else
            {
                Console.WriteLine("Не равны");
            }
            Console.ReadKey();
        }
    }
}
