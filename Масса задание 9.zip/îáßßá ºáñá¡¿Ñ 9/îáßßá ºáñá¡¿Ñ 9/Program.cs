﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Масса_задание_9
{
    class Program
    {
        static void Main(string[] args)
        {
            Double Height, Weight;
            Console.WriteLine("Введите рост и вес");
            Height = Convert.ToDouble(Console.ReadLine());
            Weight = Convert.ToDouble(Console.ReadLine());
            Console.Write("Индекс массы равен = " + Weight / Height * 2);
            Console.ReadKey();
        }
    }
}
